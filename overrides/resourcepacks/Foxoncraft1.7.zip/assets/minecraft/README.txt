README:
Stugace's Roman Texture Pack (16x16) - [ROMECRAFT] - VERSION 14.5


What this texture pack replaces:

-Armor
-Most Items
-95% of the blocks
-Default Character Skin
- Mob skins
-Inventory/Furnace/Crafting GUI

0.91 FIX
-Replaced ugly half-tiles

1.00!
-Most textures now replaced!
-ARMOR FINISHED!
CLOTH: Velite Armor / Barbarian
CHAINMAIL (for cheaters): Not quite finished, but will be chainmail version of Iron
IRON: Legionnaire Armor
DIAMOND: Praetorian Armor
GOLD: Emperor Armor / Dress Armor
- New GUI!
- NEW ITEMS!
- AHHHHH!

1.1 FIX
-Updated to MC BETA Version 1.2 by adding the new blocks, items, and mob.
- Fixed reeds
- Fix fix fix.

2.0
- 32x32 ARMOR
- Most terrain textures replaced and contrast increased!
- Wheat is now wheatier!
- Diamond item now is realistic!
- Dye items are in bowls!
- Doors now have windows! (Except iron)
- Wool is now Plasterwool! (Looks like Roman plaster for building houses!)
- Real Roman paintings in 32x32

2.1 FIX!

-Darkened and roughened brick to match the theme.
- ROMAN SANDSTONE! (Forgot to make it for 2.0 :( )

3.0
- Almost EVERYTHING is different from default now!
- Sand is more "Tunisian!"
- Hostile Mobs reskinned! (Except Nether)
- Grass is darker!
- Lupis blue block now resembles the rare Roman Blue Glass!
- Items slightly revamped
- Nether blocks completely revamped (from scratch)
- Water is bluer?
- Flowers look like clusters of flowers!

3.5
-All non-nether Mobs are now retextured (either completely or just altered!) Pigs = Boars. Cows = Brown Cows. Squids = Big eyes and PINK! (Like real squids)
-PATTERNED DYED BLOCKS!
-Some edit to items. Diamonds are now in drawstring pouches. Gold tools are staffs/marching eagles/flags
-Foliage and Grass tweaked.
-Diamond block edited to match theme better
-Sandstone edited
-Gravel Edited

3.6 fix
-Edited Art
-New stone slabs (fluted for column building!)
-Squid Fixed

4.0
- All blocks now Romecraft approved!
- All MOBs edited/recreated!
- 1.3 Compatible!
- NEW HUD!
- Many textures improved and edited!

4.1
- Fixed Magenta and Pink dye items being in the wrong spots
- 'Finished' a few 'unfinished' textures.
- Creeper has a new skin
- Fixed a few pixel errors

4.2
- Minecraft 1.4 compatible

4.3
- Should be 1.5 Compatible
- Dogs finally have new skin

5.0
-1.6.6 Compatible

5.1
-Fixed map icon

5.5
-1.7 Compatible!
-Grates now less black, more red (black is an ugly color!)
-Piston textures done
-Slime turned green again.

6.0
-Armored Zombies!
-Improved Skeletons!
-Cracking Creepers!
-Apicius' Honey-Almond Cake!
-Improved textures of all sorts (Though barely discernable to the average user: ex: Stone/Cobble has been colorized a little more, as the gray was depressing me.)
-Fixed cake
-Roman Maps
-"New-improved" Items: Sugar, Gunpowder, Experimental new Buckets (Now jugs!), Redstone, Glowstone-dust, Clay, clock, compass
-"New-improved" Netherrack, Glowstone, Slowsand, Doors, windows
(Netherack has taken the role of Roman cobblestone, which was used mainly for roads.  Hurray for historically-accurate Roman cobblestone roads, that may be flammable!)

6.2
-Modified door to be less dramatic
-Sandstone looks like.. sandstone. Finally.
-New GUI buttons/HUD
-Tweaked many textures.  
-Changed Blue block to be more attractive
Please respond to my forum on Minecraftforum.net to give me suggestions and advice for further versions.

7.0 
-1.8 UPDATE COMPATIBLE!
- Changed a few of the 1.8 textures, may change the Melon and a few others eventually.

7.1
-Fixed Watermelon slice pixels
-New title screen
-Sugarcane more Olivey?

8.0/1 - Ready for 1.0.0!

8.5 - Updated for 1.1, some item modifications as well.

9.0 - Updated many textures, edited some others - supdued some outdated coloring and revamped armor/weapons! 

9.5 - 1.2 Compatibility! This is a beta version, the full version completely updated to Romecraft 10.0 will be out in a bit!

9.8
-1.2.4 compatible, some textures that I have added may change by 10.0

10.0
- SUPER ARMOR UPDATE! YAY
- Updated some blocks and armor for improvements sake
- Art is on its way to a new direction still, though I'm still not sure where to.
- Some item changes.

10.1
-Weapon and tool tweaks, overall longer/more detailed. (Especially gold)

10.5
- Began preparation for MC 1.3
- Edited some terrain blocks 
(marble, columns, gold, and others I forget about)
- Edited armor slightly

11
Updated for 1.3 plus tons of new stuff!

11.1 
Fixed new stuff!

11.5
Texture block edits!
Basic 1.4 Compatibility!!!

12
Fixed a bunch o bugs.
Even more 1.4 Compatibility.
Improved trees!
Improved items!

12.2
-Fixed a few bugs
-Added Romecraft HD font, for Optifine and McPatcher users.
-A few other tweaks

13
Update for MC 1.5
Switched to 16x/32x HYBRID

14
- Update to 1.6!
- PAINTING OVERHAUL (5 left to complete)
- Item changes, overhauling, and tweaks!
- Horses and horse armor changes! (Armor is now horse blankets, romans did not have horse armor generally!)
- NEW MUSIC
- NEW LANGUAGE FORMAT (Items names are now different, but not vastly so.  Only applies to US English settings)
- New blocks and items romanized
- New splash.txt
- Tweaks to environment/sun
-  New title screen
- Bug fixes
- MOB tweaks
- Further optifine compatibility
CHANGES FOR NEXT UPDATE:
+Painting Overhaul need to be finished
+Horses may need new skins
+ Further MOB tweaking
+ More items converted
+ Bug fixes in item names?

14.5
- Update to 1.7.2
- Updated 1.7.2 textures (flowers, new wood, new color panes)
- Changed all items to 32x32, first version.
- Updated a few blocks to 32x32. 


